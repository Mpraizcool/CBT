<?php
include_once("config.php");
$der = mysqli_query($con,"INSERT INTO maths(Question, ans1, ans2, ans3, ans4, ans5, correctans) VALUES ('ASAS', 'ASAS', 'ASAS', 'ASAS', 'ASAS', 'ASAS', 'ASAS')");


?>