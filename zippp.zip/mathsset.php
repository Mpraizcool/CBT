<?php
session_start();
//error_reporting(0);
include('config.php');
include('checklogin.php');
check_login();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Dashboard- Client area</title>
        <link rel="stylesheet"href="style.css"/>
<style>
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
  background-color: #04AA6D;
  color: white;
}
</style>
</head>
<body>
<div class="form">
<h2>View Results</h2>

<table>
  <tr>
    <th>Firstname</th>
    <th>Lastname</th>
    <th>Savings</th>
  </tr>
  <tr>
    <td>Peter</td>
    <td>Griffin</td>
    <td>$100</td>
  </tr>
  <tr>
    <td>Lois</td>
    <td>Griffin</td>
    <td>$150</td>
  </tr>
  <tr>
    <td>Joe</td>
    <td>Swanson</td>
    <td>$300</td>
  </tr>
  <tr>
    <td>Cleveland</td>
    <td>Brown</td>
    <td>$250</td>
</tr>
</table>


        <p>Hey,<?php echo $_SESSION['login']; ?>!</p>
        <p>You are now user dashboard page.</p>
        <p><a href="new.php">Write exam</a></p>
        <p><a href="logout.php">Logout</a></p>
</div>
</body>
</html>