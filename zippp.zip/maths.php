<?php
session_start();
//error_reporting(0);
include('../config.php');
include('checklogin.php');
check_login();
if(isset($_POST['submit']))
{
$q1=$_POST["q1"];
$ans1a=$_POST["ans1a"];
$ans1b=$_POST["ans1b"];
$ans1c=$_POST["ans1c"];
$ans1d=$_POST["ans1d"];
$ans1e=$_POST["ans1e"];
$q2=$_POST["q2"];
$ans2a=$_POST["ans2a"];
$ans2b=$_POST["ans2b"];
$ans2c=$_POST["ans2c"];
$ans2d=$_POST["ans2d"];
$ans2e=$_POST["ans2e"];
$q3=$_POST["q3"];
$ans3a=$_POST["ans3a"];
$ans3b=$_POST["ans3b"];
$ans3c=$_POST["ans3c"];
$ans3d=$_POST["ans3d"];
$ans3e=$_POST["ans3e"];
$q4=$_POST["q4"];
$ans4a=$_POST["ans4a"];
$ans4b=$_POST["ans4b"];
$ans4c=$_POST["ans4c"];
$ans4d=$_POST["ans4d"];
$ans4e=$_POST["ans4e"];
$q5=$_POST["q5"];
$ans5a=$_POST["ans5a"];
$ans5b=$_POST["ans5b"];
$ans5c=$_POST["ans5c"];
$ans5d=$_POST["ans5d"];
$ans5e=$_POST["ans5e"];
$q6=$_POST["q6"];
$ans6a=$_POST["ans6a"];
$ans6b=$_POST["ans6b"];
$ans6c=$_POST["ans6c"];
$ans6d=$_POST["ans6d"];
$ans6e=$_POST["ans6e"];
$q7=$_POST["q2"];
$ans7a=$_POST["ans7a"];
$ans7b=$_POST["ans7b"];
$ans7c=$_POST["ans7c"];
$ans7d=$_POST["ans7d"];
$ans7e=$_POST["ans7e"];
$q8=$_POST["q8"];
$ans8a=$_POST["ans8a"];
$ans8b=$_POST["ans8b"];
$ans8c=$_POST["ans8c"];
$ans8d=$_POST["ans8d"];
$ans8e=$_POST["ans8e"];
$q9=$_POST["q9"];
$ans9a=$_POST["ans9a"];
$ans9b=$_POST["ans9b"];
$ans9c=$_POST["ans9c"];
$ans9d=$_POST["ans9d"];
$ans9e=$_POST["ans9e"];
$q10=$_POST["q10"];
$ans10a=$_POST["ans10a"];
$ans10b=$_POST["ans10b"];
$ans10c=$_POST["ans10c"];
$ans10d=$_POST["ans10d"];
$ans10e=$_POST["ans10e"];
$q11=$_POST["q11"];
$ans11a=$_POST["ans11a"];
$ans11b=$_POST["ans11b"];
$ans11c=$_POST["ans11c"];
$ans11d=$_POST["ans11d"];
$ans11e=$_POST["ans11e"];
$q12=$_POST["q12"];
$ans12a=$_POST["ans12a"];
$ans12b=$_POST["ans12b"];
$ans12c=$_POST["ans12c"];
$ans12d=$_POST["ans12d"];
$ans12e=$_POST["ans12e"];
$q13=$_POST["q13"];
$ans13a=$_POST["ans13a"];
$ans13b=$_POST["ans13b"];
$ans13c=$_POST["ans13c"];
$ans13d=$_POST["ans13d"];
$ans13e=$_POST["ans13e"];
$q14=$_POST["q14"];
$ans14a=$_POST["ans14a"];
$ans14b=$_POST["ans14b"];
$ans14c=$_POST["ans14c"];
$ans14d=$_POST["ans14d"];
$ans14e=$_POST["ans14e"];
$q15=$_POST["q15"];
$ans15a=$_POST["ans15a"];
$ans15b=$_POST["ans15b"];
$ans15c=$_POST["ans15c"];
$ans15d=$_POST["ans15d"];
$ans15e=$_POST["ans15e"];
$q16=$_POST["q16"];
$ans16a=$_POST["ans16a"];
$ans16b=$_POST["ans16b"];
$ans16c=$_POST["ans16c"];
$ans16d=$_POST["ans16d"];
$ans16e=$_POST["ans16e"];
$q17=$_POST["q17"];
$ans17a=$_POST["ans17a"];
$ans17b=$_POST["ans17b"];
$ans17c=$_POST["ans17c"];
$ans17d=$_POST["ans17d"];
$ans17e=$_POST["ans17e"];
$q18=$_POST["q18"];
$ans18a=$_POST["ans18a"];
$ans18b=$_POST["ans18b"];
$ans18c=$_POST["ans18c"];
$ans18d=$_POST["ans18d"];
$ans18e=$_POST["ans18e"];
$q19=$_POST["q19"];
$ans19a=$_POST["ans19a"];
$ans19b=$_POST["ans19b"];
$ans19c=$_POST["ans19c"];
$ans19d=$_POST["ans19d"];
$ans19e=$_POST["ans19e"];
$q20=$_POST["q20"];
$ans20a=$_POST["ans20a"];
$ans20b=$_POST["ans20b"];
$ans20c=$_POST["ans20c"];
$ans20d=$_POST["ans20d"];
$ans20e=$_POST["ans20e"];
$correctans1=$_POST["correctans1"];
$correctans2=$_POST["correctans2"];
$correctans3=$_POST["correctans3"];
$correctans4=$_POST["correctans4"];
$correctans5=$_POST["correctans5"];
$correctans6=$_POST["correctans6"];
$correctans7=$_POST["correctans7"];
$correctans8=$_POST["correctans8"];
$correctans9=$_POST["correctans9"];
$correctans10=$_POST["correctans10"];
$correctans11=$_POST["correctans11"];
$correctans12=$_POST["correctans12"];
$correctans13=$_POST["correctans13"];
$correctans14=$_POST["correctans14"];
$correctans15=$_POST["correctans15"];
$correctans16=$_POST["correctans16"];
$correctans17=$_POST["correctans17"];
$correctans18=$_POST["correctans18"];
$correctans19=$_POST["correctans19"];
$correctans20=$_POST["correctans20"];
$sete=mysqli_query($con, "UPDATE maths SET Question='$q1' WHERE id=1");
$sete=mysqli_query($con, "UPDATE maths SET ans1='$ans1a' WHERE id=1");
$sete=mysqli_query($con, "UPDATE maths SET ans2='$ans1b' WHERE id=1");
$sete=mysqli_query($con, "UPDATE maths SET ans3='$ans1c' WHERE id=1");
$sete=mysqli_query($con, "UPDATE maths SET ans4='$ans1d' WHERE id=1");
$sete=mysqli_query($con, "UPDATE maths SET ans5='$ans1e' WHERE id=1");
$sete=mysqli_query($con, "UPDATE maths SET Question='$q2' WHERE id=2");
$sete=mysqli_query($con, "UPDATE maths SET ans1='$ans2a' WHERE id=2");
$sete=mysqli_query($con, "UPDATE maths SET ans2='$ans2b' WHERE id=2");
$sete=mysqli_query($con, "UPDATE maths SET ans3='$ans2c' WHERE id=2");
$sete=mysqli_query($con, "UPDATE maths SET ans4='$ans2d' WHERE id=2");
$sete=mysqli_query($con, "UPDATE maths SET ans5='$ans2e' WHERE id=2");
$sete=mysqli_query($con, "UPDATE maths SET Question='$q3' WHERE id=3");
$sete=mysqli_query($con, "UPDATE maths SET ans1='$ans3a' WHERE id=3");
$sete=mysqli_query($con, "UPDATE maths SET ans2='$ans3b' WHERE id=3");
$sete=mysqli_query($con, "UPDATE maths SET ans3='$ans3c' WHERE id=3");
$sete=mysqli_query($con, "UPDATE maths SET ans4='$ans3d' WHERE id=3");
$sete=mysqli_query($con, "UPDATE maths SET ans5='$ans3e' WHERE id=3");
$sete=mysqli_query($con, "UPDATE maths SET Question='$q4' WHERE id=4");
$sete=mysqli_query($con, "UPDATE maths SET ans1='$ans4a' WHERE id=4");
$sete=mysqli_query($con, "UPDATE maths SET ans2='$ans4b' WHERE id=4");
$sete=mysqli_query($con, "UPDATE maths SET ans3='$ans4c' WHERE id=4");
$sete=mysqli_query($con, "UPDATE maths SET ans4='$ans4d' WHERE id=4");
$sete=mysqli_query($con, "UPDATE maths SET ans5='$ans4e' WHERE id=4");
$sete=mysqli_query($con, "UPDATE maths SET Question='$q5' WHERE id=5");
$sete=mysqli_query($con, "UPDATE maths SET ans1='$ans5a' WHERE id=5");
$sete=mysqli_query($con, "UPDATE maths SET ans2='$ans5b' WHERE id=5");
$sete=mysqli_query($con, "UPDATE maths SET ans3='$ans5c' WHERE id=5");
$sete=mysqli_query($con, "UPDATE maths SET ans4='$ans5d' WHERE id=5");
$sete=mysqli_query($con, "UPDATE maths SET ans5='$ans5e' WHERE id=5");
$sete=mysqli_query($con, "UPDATE maths SET Question='$q6' WHERE id=6");
$sete=mysqli_query($con, "UPDATE maths SET ans1='$ans6a' WHERE id=6");
$sete=mysqli_query($con, "UPDATE maths SET ans2='$ans6b' WHERE id=6");
$sete=mysqli_query($con, "UPDATE maths SET ans3='$ans6c' WHERE id=6");
$sete=mysqli_query($con, "UPDATE maths SET ans4='$ans6d' WHERE id=6");
$sete=mysqli_query($con, "UPDATE maths SET ans5='$ans6e' WHERE id=6");
$sete=mysqli_query($con, "UPDATE maths SET Question='$q7' WHERE id=7");
$sete=mysqli_query($con, "UPDATE maths SET ans1='$ans7a' WHERE id=7");
$sete=mysqli_query($con, "UPDATE maths SET ans2='$ans7b' WHERE id=7");
$sete=mysqli_query($con, "UPDATE maths SET ans3='$ans7c' WHERE id=7");
$sete=mysqli_query($con, "UPDATE maths SET ans4='$ans7d' WHERE id=7");
$sete=mysqli_query($con, "UPDATE maths SET ans5='$ans7e' WHERE id=7");
$sete=mysqli_query($con, "UPDATE maths SET Question='$q8' WHERE id=8");
$sete=mysqli_query($con, "UPDATE maths SET ans1='$ans8a' WHERE id=8");
$sete=mysqli_query($con, "UPDATE maths SET ans2='$ans8b' WHERE id=8");
$sete=mysqli_query($con, "UPDATE maths SET ans3='$ans8c' WHERE id=8");
$sete=mysqli_query($con, "UPDATE maths SET ans4='$ans8d' WHERE id=8");
$sete=mysqli_query($con, "UPDATE maths SET ans5='$ans8e' WHERE id=8");
$sete=mysqli_query($con, "UPDATE maths SET Question='$q9' WHERE id=9");
$sete=mysqli_query($con, "UPDATE maths SET ans1='$ans9a' WHERE id=9");
$sete=mysqli_query($con, "UPDATE maths SET ans2='$ans9b' WHERE id=9");
$sete=mysqli_query($con, "UPDATE maths SET ans3='$ans9c' WHERE id=9");
$sete=mysqli_query($con, "UPDATE maths SET ans4='$ans9d' WHERE id=9");
$sete=mysqli_query($con, "UPDATE maths SET ans5='$ans9e' WHERE id=9");
$sete=mysqli_query($con, "UPDATE maths SET Question='$q10' WHERE id=10");
$sete=mysqli_query($con, "UPDATE maths SET ans1='$ans10a' WHERE id=10");
$sete=mysqli_query($con, "UPDATE maths SET ans2='$ans10b' WHERE id=10");
$sete=mysqli_query($con, "UPDATE maths SET ans3='$ans10c' WHERE id=10");
$sete=mysqli_query($con, "UPDATE maths SET ans4='$ans10d' WHERE id=10");
$sete=mysqli_query($con, "UPDATE maths SET ans5='$ans10e' WHERE id=10");
$sete=mysqli_query($con, "UPDATE maths SET Question='$q11' WHERE id=11");
$sete=mysqli_query($con, "UPDATE maths SET ans1='$ans11a' WHERE id=11");
$sete=mysqli_query($con, "UPDATE maths SET ans2='$ans11b' WHERE id=11");
$sete=mysqli_query($con, "UPDATE maths SET ans3='$ans11c' WHERE id=11");
$sete=mysqli_query($con, "UPDATE maths SET ans4='$ans11d' WHERE id=11");
$sete=mysqli_query($con, "UPDATE maths SET ans5='$ans11e' WHERE id=11");
$sete=mysqli_query($con, "UPDATE maths SET Question='$q12' WHERE id=12");
$sete=mysqli_query($con, "UPDATE maths SET ans1='$ans12a' WHERE id=12");
$sete=mysqli_query($con, "UPDATE maths SET ans2='$ans12b' WHERE id=12");
$sete=mysqli_query($con, "UPDATE maths SET ans3='$ans12c' WHERE id=12");
$sete=mysqli_query($con, "UPDATE maths SET ans4='$ans12d' WHERE id=12");
$sete=mysqli_query($con, "UPDATE maths SET ans5='$ans12e' WHERE id=12");
$sete=mysqli_query($con, "UPDATE maths SET Question='$q13' WHERE id=13");
$sete=mysqli_query($con, "UPDATE maths SET ans1='$ans13a' WHERE id=13");
$sete=mysqli_query($con, "UPDATE maths SET ans2='$ans13b' WHERE id=13");
$sete=mysqli_query($con, "UPDATE maths SET ans3='$ans13c' WHERE id=13");
$sete=mysqli_query($con, "UPDATE maths SET ans4='$ans13d' WHERE id=13");
$sete=mysqli_query($con, "UPDATE maths SET ans5='$ans13e' WHERE id=13");
$sete=mysqli_query($con, "UPDATE maths SET Question='$q14' WHERE id=14");
$sete=mysqli_query($con, "UPDATE maths SET ans1='$ans14a' WHERE id=14");
$sete=mysqli_query($con, "UPDATE maths SET ans2='$ans14b' WHERE id=14");
$sete=mysqli_query($con, "UPDATE maths SET ans3='$ans14c' WHERE id=14");
$sete=mysqli_query($con, "UPDATE maths SET ans4='$ans14d' WHERE id=14");
$sete=mysqli_query($con, "UPDATE maths SET ans5='$ans14e' WHERE id=14");
$sete=mysqli_query($con, "UPDATE maths SET Question='$q15' WHERE id=15");
$sete=mysqli_query($con, "UPDATE maths SET ans1='$ans15a' WHERE id=15");
$sete=mysqli_query($con, "UPDATE maths SET ans2='$ans15b' WHERE id=15");
$sete=mysqli_query($con, "UPDATE maths SET ans3='$ans15c' WHERE id=15");
$sete=mysqli_query($con, "UPDATE maths SET ans4='$ans15d' WHERE id=15");
$sete=mysqli_query($con, "UPDATE maths SET ans5='$ans15e' WHERE id=15");
$csete=mysqli_query($con, "UPDATE maths SET Question='$q16' WHERE id=16");
$csete=mysqli_query($con, "UPDATE maths SET ans1='$ans16a' WHERE id=16");
$csete=mysqli_query($con, "UPDATE maths SET ans2='$ans16b' WHERE id=16");
$csete=mysqli_query($con, "UPDATE maths SET ans3='$ans16c' WHERE id=16");
$csete=mysqli_query($con, "UPDATE maths SET ans4='$ans16d' WHERE id=16");
$csete=mysqli_query($con, "UPDATE maths SET ans5='$ans16e' WHERE id=16");
$csete=mysqli_query($con, "UPDATE maths SET Question='$q17' WHERE id=17");
$csete=mysqli_query($con, "UPDATE maths SET ans1='$ans17a' WHERE id=17");
$csete=mysqli_query($con, "UPDATE maths SET ans2='$ans17b' WHERE id=17");
$csete=mysqli_query($con, "UPDATE maths SET ans3='$ans17c' WHERE id=17");
$csete=mysqli_query($con, "UPDATE maths SET ans4='$ans17d' WHERE id=17");
$csete=mysqli_query($con, "UPDATE maths SET ans5='$ans17e' WHERE id=17");
$csete=mysqli_query($con, "UPDATE maths SET Question='$q18' WHERE id=18");
$csete=mysqli_query($con, "UPDATE maths SET ans1='$ans18a' WHERE id=18");
$csete=mysqli_query($con, "UPDATE maths SET ans2='$ans18b' WHERE id=18");
$csete=mysqli_query($con, "UPDATE maths SET ans3='$ans18c' WHERE id=18");
$csete=mysqli_query($con, "UPDATE maths SET ans4='$ans18d' WHERE id=18");
$csete=mysqli_query($con, "UPDATE maths SET ans5='$ans18e' WHERE id=18");
$csete=mysqli_query($con, "UPDATE maths SET Question='$q19' WHERE id=19");
$csete=mysqli_query($con, "UPDATE maths SET ans1='$ans19a' WHERE id=19");
$csete=mysqli_query($con, "UPDATE maths SET ans2='$ans19b' WHERE id=19");
$csete=mysqli_query($con, "UPDATE maths SET ans3='$ans19c' WHERE id=19");
$csete=mysqli_query($con, "UPDATE maths SET ans4='$ans19d' WHERE id=19");
$csete=mysqli_query($con, "UPDATE maths SET ans5='$ans19e' WHERE id=19");
$csete=mysqli_query($con, "UPDATE maths SET Question='$q20' WHERE id=20");
$csete=mysqli_query($con, "UPDATE maths SET ans1='$ans20a' WHERE id=20");
$csete=mysqli_query($con, "UPDATE maths SET ans2='$ans20b' WHERE id=20");
$csete=mysqli_query($con, "UPDATE maths SET ans3='$ans20c' WHERE id=20");
$csete=mysqli_query($con, "UPDATE maths SET ans4='$ans20d' WHERE id=20");
$csete=mysqli_query($con, "UPDATE maths SET ans5='$ans20e' WHERE id=20");
$csete=mysqli_query($con, "UPDATE maths SET correctans='$correctans1' WHERE id=1");
$csete=mysqli_query($con, "UPDATE maths SET correctans='$correctans2' WHERE id=2");
$csete=mysqli_query($con, "UPDATE maths SET correctans='$correctans3' WHERE id=3");
$csete=mysqli_query($con, "UPDATE maths SET correctans='$correctans4' WHERE id=4");
$csete=mysqli_query($con, "UPDATE maths SET correctans='$correctans5' WHERE id=5");
$csete=mysqli_query($con, "UPDATE maths SET correctans='$correctans6' WHERE id=6");
$csete=mysqli_query($con, "UPDATE maths SET correctans='$correctans7' WHERE id=7");
$csete=mysqli_query($con, "UPDATE maths SET correctans='$correctans8' WHERE id=8");
$csete=mysqli_query($con, "UPDATE maths SET correctans='$correctans9' WHERE id=9");
$csete=mysqli_query($con, "UPDATE maths SET correctans='$correctans10' WHERE id=10");
$csete=mysqli_query($con, "UPDATE maths SET correctans='$correctans11' WHERE id=11");
$csete=mysqli_query($con, "UPDATE maths SET correctans='$correctans12' WHERE id=12");
$csete=mysqli_query($con, "UPDATE maths SET correctans='$correctans13' WHERE id=13");
$csete=mysqli_query($con, "UPDATE maths SET correctans='$correctans14' WHERE id=14");
$csete=mysqli_query($con, "UPDATE maths SET correctans='$correctans15' WHERE id=15");
$csete=mysqli_query($con, "UPDATE maths SET correctans='$correctans16' WHERE id=16");
$csete=mysqli_query($con, "UPDATE maths SET correctans='$correctans17' WHERE id=17");
$csete=mysqli_query($con, "UPDATE maths SET correctans='$correctans18' WHERE id=18");
$csete=mysqli_query($con, "UPDATE maths SET correctans='$correctans19' WHERE id=19");
$csete=mysqli_query($con, "UPDATE maths SET correctans='$correctans20' WHERE id=20");
if ($sete) {
    echo "<script>alert('Questions successfully set');</script>";
}
else
{ echo "<script>alert('Failed, try again');</script>";
}
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <link rel="stylesheet" href="../style.css">
    <title>Set Maths Test</title>
</head>
<body>
    <form class="form" method="post">
    <p><a href="dashboard.php">Dashboard</a></p>
    <h2>Set Maths Test</h2>
    <label for="1">1.</label><input type="text" class="bvs" name="q1" placeholder="First Question"><br><br>
    <label for="1">A.</label><input type="text" class="bv" name="ans1a" placeholder="First Answer"><br>
    <label for="1">B.</label><input type="text" class="bv" name="ans1b" placeholder="Second Answer"><br>
    <label for="1">C.</label><input type="text" class="bv" name="ans1c" placeholder="Third Answer"><br>
    <label for="1">D.</label><input type="text" class="bv" name="ans1d" placeholder="Fourth Answer"><br>
    <label for="1">E.</label><input type="text" class="bv" name="ans1e" placeholder="Fifth Answer"><br>
    <input type="text" class="bva" name="correctans1" placeholder="Correct Answer"><br>
    <br>
    <label for="2">2.</label><input type="text" class="bvs" name="q2" placeholder="Second Question"><br><br>
    <label for="2">A.</label><input type="text" class="bv" name="ans2a" placeholder="First Answer"><br>
    <label for="2">B.</label><input type="text" class="bv" name="ans2b" placeholder="Second Answer"><br>
    <label for="2">C.</label><input type="text" class="bv" name="ans2c" placeholder="Third Answer"><br>
    <label for="2">D.</label><input type="text" class="bv" name="ans2d" placeholder="Fourth Answer"><br>
    <label for="2">E.</label><input type="text" class="bv" name="ans2e" placeholder="Fifth Answer"><br>
    <input type="text" class="bva" name="correctans2" placeholder="Correct Answer"><br>
    <br>
    <label for="3">3.</label><input type="text" class="bvs" name="q3" placeholder="Third Question"><br><br>
    <label for="3">A.</label><input type="text" class="bv" name="ans3a" placeholder="First Answer"><br>
    <label for="3">B.</label><input type="text" class="bv" name="ans3b" placeholder="Second Answer"><br>
    <label for="3">C.</label><input type="text" class="bv" name="ans3c" placeholder="Third Answer"><br>
    <label for="3">D.</label><input type="text" class="bv" name="ans3d" placeholder="Fourth Answer"><br>
    <label for="3">E.</label><input type="text" class="bv" name="ans3e" placeholder="Fifth Answer"><br>
    <input type="text" class="bva" name="correctans3" placeholder="Correct Answer"><br>
    <br>
    <label for="4">4.</label><input type="text" class="bvs" name="q4" placeholder="Fourth Question"><br><br>
    <label for="4">A.</label><input type="text" class="bv" name="ans4a" placeholder="First Answer"><br>
    <label for="4">B.</label><input type="text" class="bv" name="ans4b" placeholder="Second Answer"><br>
    <label for="4">C.</label><input type="text" class="bv" name="ans4c" placeholder="Third Answer"><br>
    <label for="4">D.</label><input type="text" class="bv" name="ans4d" placeholder="Fourth Answer"><br>
    <label for="4">E.</label><input type="text" class="bv" name="ans4e" placeholder="Fifth Answer"><br>
    <input type="text" class="bva" name="correctans4" placeholder="Correct Answer"><br>
    <br>
    <label for="5">5.</label><input type="text" class="bvs" name="q5" placeholder="Fifth Question"><br><br>
    <label for="5">A.</label><input type="text" class="bv" name="ans5a" placeholder="First Answer"><br>
    <label for="5">B.</label><input type="text" class="bv" name="ans5b" placeholder="Second Answer"><br>
    <label for="5">C.</label><input type="text" class="bv" name="ans5c" placeholder="Third Answer"><br>
    <label for="5">D.</label><input type="text" class="bv" name="ans5d" placeholder="Fourth Answer"><br>
    <label for="5">E.</label><input type="text" class="bv" name="ans5e" placeholder="Fifth Answer"><br>
    <input type="text" class="bva" name="correctans5" placeholder="Correct Answer"><br>
    <br>
    <label for="6">6.</label><input type="text" class="bvs" name="q6" placeholder="Sixth Question"><br><br>
    <label for="6">A.</label><input type="text" class="bv" name="ans6a" placeholder="First Answer"><br>
    <label for="6">B.</label><input type="text" class="bv" name="ans6b" placeholder="Second Answer"><br>
    <label for="6">C.</label><input type="text" class="bv" name="ans6c" placeholder="Third Answer"><br>
    <label for="6">D.</label><input type="text" class="bv" name="ans6d" placeholder="Fourth Answer"><br>
    <label for="6">E.</label><input type="text" class="bv" name="ans6e" placeholder="Fifth Answer"><br>
    <input type="text" class="bva" name="correctans6" placeholder="Correct Answer"><br>
    <br>
    <label for="7">7.</label><input type="text" class="bvs" name="q7" placeholder="Seventh Question"><br><br>
    <label for="7">A.</label><input type="text" class="bv" name="ans7a" placeholder="First Answer"><br>
    <label for="7">B.</label><input type="text" class="bv" name="ans7b" placeholder="Second Answer"><br>
    <label for="7">C.</label><input type="text" class="bv" name="ans7c" placeholder="Third Answer"><br>
    <label for="7">D.</label><input type="text" class="bv" name="ans7d" placeholder="Fourth Answer"><br>
    <label for="7">E.</label><input type="text" class="bv" name="ans7e" placeholder="Fifth Answer"><br>
    <input type="text" class="bva" name="correctans7" placeholder="Correct Answer"><br>
    <br>
    <label for="8">8.</label><input type="text" class="bvs" name="q8" placeholder="Eighth Question"><br><br>
    <label for="8">A.</label><input type="text" class="bv" name="ans8a" placeholder="First Answer"><br>
    <label for="8">B.</label><input type="text" class="bv" name="ans8b" placeholder="Second Answer"><br>
    <label for="8">C.</label><input type="text" class="bv" name="ans8c" placeholder="Third Answer"><br>
    <label for="8">D.</label><input type="text" class="bv" name="ans8d" placeholder="Fourth Answer"><br>
    <label for="8">E.</label><input type="text" class="bv" name="ans8e" placeholder="Fifth Answer"><br>
    <input type="text" class="bva" name="correctans8" placeholder="Correct Answer"><br>
    <br>
    <label for="9">9.</label><input type="text" class="bvs" name="q9" placeholder="Ninth Question"><br><br>
    <label for="9">A.</label><input type="text" class="bv" name="ans9a" placeholder="First Answer"><br>
    <label for="9">B.</label><input type="text" class="bv" name="ans9b" placeholder="Second Answer"><br>
    <label for="9">C.</label><input type="text" class="bv" name="ans9c" placeholder="Third Answer"><br>
    <label for="9">D.</label><input type="text" class="bv" name="ans9d" placeholder="Fourth Answer"><br>
    <label for="9">E.</label><input type="text" class="bv" name="ans9e" placeholder="Fifth Answer"><br>
    <input type="text" class="bva" name="correctans9" placeholder="Correct Answer"><br>
    <br>
    <label for="10">10.</label><input type="text" class="bvs" name="q10" placeholder="Tenth Question"><br><br>
    <label for="10">A.</label><input type="text" class="bv" name="ans10a" placeholder="First Answer"><br>
    <label for="10">B.</label><input type="text" class="bv" name="ans10b" placeholder="Second Answer"><br>
    <label for="10">C.</label><input type="text" class="bv" name="ans10c" placeholder="Third Answer"><br>
    <label for="10">D.</label><input type="text" class="bv" name="ans10d" placeholder="Fourth Answer"><br>
    <label for="10">E.</label><input type="text" class="bv" name="ans10e" placeholder="Fifth Answer"><br>
    <input type="text" class="bva" name="correctans10" placeholder="Correct Answer"><br>
    <br>
    <label for="11">11.</label><input type="text" class="bvs" name="q11" placeholder="Eleventh Question"><br><br>
    <label for="11">A.</label><input type="text" class="bv" name="ans11a" placeholder="First Answer"><br>
    <label for="11">B.</label><input type="text" class="bv" name="ans11b" placeholder="Second Answer"><br>
    <label for="11">C.</label><input type="text" class="bv" name="ans11c" placeholder="Third Answer"><br>
    <label for="11">D.</label><input type="text" class="bv" name="ans11d" placeholder="Fourth Answer"><br>
    <label for="11">E.</label><input type="text" class="bv" name="ans11e" placeholder="Fifth Answer"><br>
    <input type="text" class="bva" name="correctans11" placeholder="Correct Answer"><br>
    <br>
    <label for="12">12.</label><input type="text" class="bvs" name="q12" placeholder="Twelveth Question"><br><br>
    <label for="12">A.</label><input type="text" class="bv" name="ans12a" placeholder="First Answer"><br>
    <label for="12">B.</label><input type="text" class="bv" name="ans12b" placeholder="Second Answer"><br>
    <label for="12">C.</label><input type="text" class="bv" name="ans12c" placeholder="Third Answer"><br>
    <label for="12">D.</label><input type="text" class="bv" name="ans12d" placeholder="Fourth Answer"><br>
    <label for="12">E.</label><input type="text" class="bv" name="ans12e" placeholder="Fifth Answer"><br>
    <input type="text" class="bva" name="correctans12" placeholder="Correct Answer"><br>
    <br>
    <label for="13">13.</label><input type="text" class="bvs" name="q13" placeholder="Thirteenth Question"><br><br>
    <label for="13">A.</label><input type="text" class="bv" name="ans13a" placeholder="First Answer"><br>
    <label for="13">B.</label><input type="text" class="bv" name="ans13b" placeholder="Second Answer"><br>
    <label for="13">C.</label><input type="text" class="bv" name="ans13c" placeholder="Third Answer"><br>
    <label for="13">D.</label><input type="text" class="bv" name="ans13d" placeholder="Fourth Answer"><br>
    <label for="13">E.</label><input type="text" class="bv" name="ans13e" placeholder="Fifth Answer"><br>
    <input type="text" class="bva" name="correctans13" placeholder="Correct Answer"><br>
    <br>
    <label for="14">14.</label><input type="text" class="bvs" name="q14" placeholder="Fourteenth Question"><br><br>
    <label for="14">A.</label><input type="text" class="bv" name="ans14a" placeholder="First Answer"><br>
    <label for="14">B.</label><input type="text" class="bv" name="ans14b" placeholder="Second Answer"><br>
    <label for="14">C.</label><input type="text" class="bv" name="ans14c" placeholder="Third Answer"><br>
    <label for="14">D.</label><input type="text" class="bv" name="ans14d" placeholder="Fourth Answer"><br>
    <label for="14">E.</label><input type="text" class="bv" name="ans14e" placeholder="Fifth Answer"><br>
    <input type="text" class="bva" name="correctans14" placeholder="Correct Answer"><br>
    <br>
    <label for="15">15.</label><input type="text" class="bvs" name="q15" placeholder="Fifteenth Question"><br><br>
    <label for="15">A.</label><input type="text" class="bv" name="ans15a" placeholder="First Answer"><br>
    <label for="15">B.</label><input type="text" class="bv" name="ans15b" placeholder="Second Answer"><br>
    <label for="15">C.</label><input type="text" class="bv" name="ans15c" placeholder="Third Answer"><br>
    <label for="15">D.</label><input type="text" class="bv" name="ans15d" placeholder="Fourth Answer"><br>
    <label for="15">E.</label><input type="text" class="bv" name="ans15e" placeholder="Fifth Answer"><br>
    <input type="text" class="bva" name="correctans15" placeholder="Correct Answer"><br>
    <br>
    <label for="16">16.</label><input type="text" class="bvs" name="q16" placeholder="Sixteenth Question"><br><br>
    <label for="16">A.</label><input type="text" class="bv" name="ans16a" placeholder="First Answer"><br>
    <label for="16">B.</label><input type="text" class="bv" name="ans16b" placeholder="Second Answer"><br>
    <label for="16">C.</label><input type="text" class="bv" name="ans16c" placeholder="Third Answer"><br>
    <label for="16">D.</label><input type="text" class="bv" name="ans16d" placeholder="Fourth Answer"><br>
    <label for="16">E.</label><input type="text" class="bv" name="ans16e" placeholder="Fifth Answer"><br>
    <input type="text" class="bva" name="correctans16" placeholder="Correct Answer"><br>
    <br>
    <label for="17">17.</label><input type="text" class="bvs" name="q17" placeholder="Seventeenth Question"><br><br>
    <label for="17">A.</label><input type="text" class="bv" name="ans17a" placeholder="First Answer"><br>
    <label for="17">B.</label><input type="text" class="bv" name="ans17b" placeholder="Second Answer"><br>
    <label for="17">C.</label><input type="text" class="bv" name="ans17c" placeholder="Third Answer"><br>
    <label for="17">D.</label><input type="text" class="bv" name="ans17d" placeholder="Fourth Answer"><br>
    <label for="17">E.</label><input type="text" class="bv" name="ans17e" placeholder="Fifth Answer"><br>
    <input type="text" class="bva" name="correctans17" placeholder="Correct Answer"><br>
    <br>
    <label for="18">18.</label><input type="text" class="bvs" name="q18" placeholder="Eighteenth Question"><br><br>
    <label for="18">A.</label><input type="text" class="bv" name="ans18a" placeholder="First Answer"><br>
    <label for="18">B.</label><input type="text" class="bv" name="ans18b" placeholder="Second Answer"><br>
    <label for="18">C.</label><input type="text" class="bv" name="ans18c" placeholder="Third Answer"><br>
    <label for="18">D.</label><input type="text" class="bv" name="ans18d" placeholder="Fourth Answer"><br>
    <label for="18">E.</label><input type="text" class="bv" name="ans18e" placeholder="Fifth Answer"><br>
    <input type="text" class="bva" name="correctans18" placeholder="Correct Answer"><br>
    <br>
    <label for="19">19.</label><input type="text" class="bvs" name="q19" placeholder="Nineteenth Question"><br><br>
    <label for="19">A.</label><input type="text" class="bv" name="ans19a" placeholder="First Answer"><br>
    <label for="19">B.</label><input type="text" class="bv" name="ans19b" placeholder="Second Answer"><br>
    <label for="19">C.</label><input type="text" class="bv" name="ans19c" placeholder="Third Answer"><br>
    <label for="19">D.</label><input type="text" class="bv" name="ans19d" placeholder="Fourth Answer"><br>
    <label for="19">E.</label><input type="text" class="bv" name="ans19e" placeholder="Fifth Answer"><br>
    <input type="text" class="bva" name="correctans19" placeholder="Correct Answer"><br>
    <br>
    <label for="20">20.</label><input type="text" class="bvs" name="q20" placeholder="Twenteenth Question"><br><br>
    <label for="20">A.</label><input type="text" class="bv" name="ans20a" placeholder="First Answer"><br>
    <label for="20">B.</label><input type="text" class="bv" name="ans20b" placeholder="Second Answer"><br>
    <label for="20">C.</label><input type="text" class="bv" name="ans20c" placeholder="Third Answer"><br>
    <label for="20">D.</label><input type="text" class="bv" name="ans20d" placeholder="Fourth Answer"><br>
    <label for="20">E.</label><input type="text" class="bv" name="ans20e" placeholder="Fifth Answer"><br>
    <input type="text" class="bva" name="correctans20" placeholder="Correct Answer"><br>
    <br>
    <input type="submit"value="Submit" name="submit" class="login-button"/>
    
</form>
</body>
</html>

