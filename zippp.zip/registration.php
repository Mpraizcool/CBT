
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Registration</title>
    <link rel="stylesheet" href="../style.css">

</head>
<body>
    <?php
    include_once('../config.php');
    if(isset($_POST['submit']))
    {
    $surname=$_POST['surname'];
    $othername=$_POST['othername'];
    $subjecte=$_POST['subjecte'];
    $email=$_POST['email'];
    $passworde=md5($_POST['passworde']);
    $query="INSERT INTO teacher(surname,othername,subjecte,email,passworde) VALUES ('$surname','$othername','$subjecte','$email','$passworde')";
        $result = mysqli_query($con,$query); 
        if($result) {
            echo "<div class='form'>
            <h3>You are registered successfully.</h3><br/>
            <p class='link'>Click here to <a href='login.php'>Login</a></p>
            </div>";
        } else {
            echo  "<div class='form'>
            <h3>Required fields are missing.</h3><br/>
            <p class='link'>Click here to <a href='registration.php'>registration</a>again.</p>
            </div>";
        }
    } else {
    ?>
        <form class= "form" action="" method="post">
            <h1 class="login-title">Registration</h1>
            <input type="text" class="login-input" name="surname" placeholder="Surname" required>
            <input type="text" class="login-input" name="othername" placeholder="Other names" required>
            <select name="subjecte" class="form-control" required="true">
				<option value="0">Select Subject</option>
                <option value="maths">Mathematics</option>
				<option value="English Language">English Language</option>
                <option value="Physics">Physics</option>
                <option value="Chemistry">Chemistry</option>
                <option value="Biology">Biology</option>
                <option value="Further Mathematics">Further Mathematics</option>
                <option value="I.C.T">I.C.T</option>
                <option value="Civic Education">Civic Education</option>
                <option value="Agricultural Science">Agricultural Science</option>
                <option value="Economics">Economics</option>
                <option value="Marketing">Marketing</option>							
			</select>
            <br><br>
            <input type="text" class="login-input" name="email" placeholder="Email Address" required>
            <input type="password" class="login-input" name="passworde" placeholder="Password" required>
            <input type="submit" name="submit" value="Register" class="login-button">
            <p class="link"><a href="login.php">Click to Login</a></p>
        </form>
    <?php
    }
    ?>    
</body>
</html>