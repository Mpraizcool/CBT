<?php
session_start();
//error_reporting(0);
include('../config.php');
include('../checklogin.php');
check_login();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Dashboard</title>
        <link rel="stylesheet"href="../style.css"/>
        <style>
a:link, a:visited {
  background-color: black;
  color: white;
  padding: 14px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}

a:hover, a:active {
  background-color: grey;
}
</style>
        
</head>
<body>

    <div class="form">
            <p>Hey,<?php echo $_SESSION['login']; ?>!</p>
        <p>You are now user dashboard page.</p><br><br>
        <?php 
    
       $a = $_SESSION['login'];
    $df= mysqli_query($con,"SELECT * FROM teacher where email='$a'");
    while($row=mysqli_fetch_array($df)){
        
        
        $extra="".$row["subjecte"].".php";//
        $host=$_SERVER['HTTP_HOST'];
        $uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
        $why="http://$host$uri/$extra";
        
        ?>
        <a href="<?php echo $why; }?>">Set Exam</a>
        <p><a href="mathsset.php">View Results</a></p>
        <p><a href="logout.php">Logout</a></p>
        
</div>
</body>
</html>